<?php

namespace Tests;

class CustomTest extends TestCase
{

}
